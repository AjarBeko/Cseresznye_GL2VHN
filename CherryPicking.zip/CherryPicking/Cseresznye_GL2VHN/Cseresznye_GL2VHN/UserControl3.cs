﻿using Cseresznye_GL2VHN.Cherry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cseresznye_GL2VHN
{
    public partial class UserControl3 : UserControl
    {
        CherryContext context = new CherryContext();
        public UserControl3()
        {

            InitializeComponent();
            context = new CherryContext();
            var autok = (from x in context.Autos
                         select x).ToList();
            autoBindingSource.DataSource = autok;
        }

        private void UserControl3_Load(object sender, EventArgs e)
        {
            if (autoBindingSource.Current == null) return;
            var auto = from x in context.Autos
                       select x;
            label1.Text = $"Az autók száma {auto.Count()}";

            try
            {

                var data = context.Autos
                    .Select(x => x.Motorcm3)
                    .ToList();


                var convert = data
                    .Where(x => int.TryParse(x, out _))
                    .Select(x => int.Parse(x))
                    .ToList();


                if (convert.Any())
                {
                    var atlagHengerurtartalom = convert.Average();
                    label2.Text = $"Az autók átlagos hengerűrtartalma: {atlagHengerurtartalom:F2} cm³";
                }
                else
                {
                    label2.Text = "Nincsenek érvényes hengerűrtartalom adatok az adatbázisban.";
                }
            }
            catch (Exception ex)
            {
                label2.Text = $"Hiba történt: {ex.Message}";
            }
        }

        private void savebutton_Click(object sender, EventArgs e)
        {
            context.SaveChanges();
        }
    }
}
