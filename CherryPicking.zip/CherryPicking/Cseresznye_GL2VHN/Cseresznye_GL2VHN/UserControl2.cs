﻿using Cseresznye_GL2VHN.Cherry;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cseresznye_GL2VHN
{
    public partial class UserControl2 : UserControl
    {
        private CherryContext context;
        private BindingList<Ugyfel> ugyfelBindingList;
        public UserControl2()
        {
            InitializeComponent();
            context = new CherryContext();
            context.Ugyfels.Load();
            ugyfelBindingList = context.Ugyfels.Local.ToBindingList();
            ugyfelBindingSource.DataSource = ugyfelBindingList;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filterString = textBox1.Text.ToLower();
            ugyfelBindingSource.DataSource = from k in ugyfelBindingList
                                             where k.Nev.ToLower().Contains(filterString) ||
                                             k.Email.ToLower().Contains(filterString) ||
                                             (k.Telefonszam != null && k.Telefonszam.Contains(filterString))
                                             orderby k.UgyfelId
                                             select k;
        }
        private void AddButton_Click(object sender, EventArgs e)
        {
            Szerkesztescs ujUgyfelForm = new Szerkesztescs();
            if (ujUgyfelForm.ShowDialog() == DialogResult.OK)
            {
                ugyfelBindingList.Add(ujUgyfelForm.szerkesztés);
                Mentés();
            }
        }
        private void Mentés()
        {
            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ModositButton_Click(object sender, EventArgs e)
        {
            if (ugyfelBindingSource.Current != null)
            {
                Szerkesztescs szerkesztes = new Szerkesztescs(ugyfelBindingSource.Current as Ugyfel);
                if (szerkesztes.ShowDialog() == DialogResult.OK)
                {
                    Mentés();
                }
                else
                {
                    context.Ugyfels.Load();
                }
            }
            else
            {
                MessageBox.Show("Nincs kiválasztva ügyfél!");
            }
        }

        private void DelButton_Click(object sender, EventArgs e)
        {
            if (ugyfelBindingSource.Current != null)
            {
                var result = MessageBox.Show("Biztosan törölni szeretné az ügyfelet?", "Törlés megerősítése",
                                      MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    ugyfelBindingSource.RemoveCurrent();
                    Mentés();
                    MessageBox.Show("Sikeres törlés!", "Sikeres",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Kérjük, válasszon ki egy ügyfelet a törléshez.", "Nincs kiválasztott ügyfél",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


    }
}
