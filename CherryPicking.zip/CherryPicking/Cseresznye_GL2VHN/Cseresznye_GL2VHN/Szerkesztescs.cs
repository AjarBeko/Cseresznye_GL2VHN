﻿using Cseresznye_GL2VHN.Cherry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cseresznye_GL2VHN
{
    public partial class Szerkesztescs : Form
    {
        public Ugyfel szerkesztés { get; set; }
        public Szerkesztescs(Ugyfel ugyfel)
        {
            InitializeComponent();
            this.szerkesztés = ugyfel;
            ugyfelBindingSource.DataSource = szerkesztés;

        }
        public Szerkesztescs()
        {
            InitializeComponent();
            this.szerkesztés = new Ugyfel();
            ugyfelBindingSource.DataSource = szerkesztés;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveButtom_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Kérjük, javítsa a hibás mezőket!");
                return;
            }
            ugyfelBindingSource.EndEdit();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            Regex rgxNev = new Regex(@"^[\p{L} .'-]+$");

            if (!rgxNev.IsMatch(textBox1.Text))
            {
                errorProvider1.SetError(textBox1, "A név csak kis- és nagybetűket jeleníthet meg.");
                e.Cancel = true;
            }
            else
            {

                errorProvider1.SetError(textBox1, "");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            Regex rgxMail = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
            if (!rgxMail.IsMatch(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "Rossz Email formátum, Tartalmaznia kell egy @ jelet, előtte és utána karakterekkel.\r\nA @ jel után legalább egy pontnak kell lennie, ami nem közvetlenül a @ jel után áll.");
                e.Cancel = true;
            }
            else
            {

                errorProvider1.SetError(textBox2, "");
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            Regex rgxPhone = new Regex(@"^\+36(20|30|31|50|70)\d{7}$");
            if (!rgxPhone.IsMatch(textBox3.Text))
            {
                errorProvider1.SetError(textBox3, "Magyar mobilszám formátumnak kell megfelelnie.\r\n+36-tal kell kezdődnie.\r\nEzt követően 20, 30, 31, 50 vagy 70 előhívó egyikével kell folytatódnia.\r\nVégül 7 számjegynek kell következnie.");
                e.Cancel = true;
            }
            else
            {

                errorProvider1.SetError(textBox3, "");
            }
        }
    }
}
