﻿namespace Cseresznye_GL2VHN
{
    partial class UserControl3
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            autoIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            gyartasiEvDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            markaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            modellDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            kivitelDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            motorcm3DataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            szarmazasDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            ugyfelIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            autoBindingSource = new BindingSource(components);
            label1 = new Label();
            label2 = new Label();
            savebutton = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)autoBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { autoIdDataGridViewTextBoxColumn, gyartasiEvDataGridViewTextBoxColumn, markaDataGridViewTextBoxColumn, modellDataGridViewTextBoxColumn, kivitelDataGridViewTextBoxColumn, motorcm3DataGridViewTextBoxColumn, szarmazasDataGridViewTextBoxColumn, ugyfelIdDataGridViewTextBoxColumn });
            dataGridView1.DataSource = autoBindingSource;
            dataGridView1.Location = new Point(0, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(796, 266);
            dataGridView1.TabIndex = 0;
            // 
            // autoIdDataGridViewTextBoxColumn
            // 
            autoIdDataGridViewTextBoxColumn.DataPropertyName = "AutoId";
            autoIdDataGridViewTextBoxColumn.HeaderText = "AutoId";
            autoIdDataGridViewTextBoxColumn.Name = "autoIdDataGridViewTextBoxColumn";
            // 
            // gyartasiEvDataGridViewTextBoxColumn
            // 
            gyartasiEvDataGridViewTextBoxColumn.DataPropertyName = "GyartasiEv";
            gyartasiEvDataGridViewTextBoxColumn.HeaderText = "GyartasiEv";
            gyartasiEvDataGridViewTextBoxColumn.Name = "gyartasiEvDataGridViewTextBoxColumn";
            // 
            // markaDataGridViewTextBoxColumn
            // 
            markaDataGridViewTextBoxColumn.DataPropertyName = "Marka";
            markaDataGridViewTextBoxColumn.HeaderText = "Marka";
            markaDataGridViewTextBoxColumn.Name = "markaDataGridViewTextBoxColumn";
            // 
            // modellDataGridViewTextBoxColumn
            // 
            modellDataGridViewTextBoxColumn.DataPropertyName = "Modell";
            modellDataGridViewTextBoxColumn.HeaderText = "Modell";
            modellDataGridViewTextBoxColumn.Name = "modellDataGridViewTextBoxColumn";
            // 
            // kivitelDataGridViewTextBoxColumn
            // 
            kivitelDataGridViewTextBoxColumn.DataPropertyName = "Kivitel";
            kivitelDataGridViewTextBoxColumn.HeaderText = "Kivitel";
            kivitelDataGridViewTextBoxColumn.Name = "kivitelDataGridViewTextBoxColumn";
            // 
            // motorcm3DataGridViewTextBoxColumn
            // 
            motorcm3DataGridViewTextBoxColumn.DataPropertyName = "Motorcm3";
            motorcm3DataGridViewTextBoxColumn.HeaderText = "Motorcm3";
            motorcm3DataGridViewTextBoxColumn.Name = "motorcm3DataGridViewTextBoxColumn";
            // 
            // szarmazasDataGridViewTextBoxColumn
            // 
            szarmazasDataGridViewTextBoxColumn.DataPropertyName = "Szarmazas";
            szarmazasDataGridViewTextBoxColumn.HeaderText = "Szarmazas";
            szarmazasDataGridViewTextBoxColumn.Name = "szarmazasDataGridViewTextBoxColumn";
            // 
            // ugyfelIdDataGridViewTextBoxColumn
            // 
            ugyfelIdDataGridViewTextBoxColumn.DataPropertyName = "UgyfelId";
            ugyfelIdDataGridViewTextBoxColumn.HeaderText = "UgyfelId";
            ugyfelIdDataGridViewTextBoxColumn.Name = "ugyfelIdDataGridViewTextBoxColumn";
            // 
            // autoBindingSource
            // 
            autoBindingSource.DataSource = typeof(Cherry.Auto);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 287);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 1;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(3, 319);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 2;
            label2.Text = "label2";
            // 
            // savebutton
            // 
            savebutton.Location = new Point(3, 337);
            savebutton.Name = "savebutton";
            savebutton.Size = new Size(75, 23);
            savebutton.TabIndex = 3;
            savebutton.Text = "Mentés";
            savebutton.UseVisualStyleBackColor = true;
            savebutton.Click += savebutton_Click;
            // 
            // UserControl3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Fuchsia;
            Controls.Add(savebutton);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Name = "UserControl3";
            Size = new Size(799, 537);
            Load += UserControl3_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)autoBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn autoIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn gyartasiEvDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn markaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn modellDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn kivitelDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn motorcm3DataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn szarmazasDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn ugyfelIdDataGridViewTextBoxColumn;
        private BindingSource autoBindingSource;
        private Label label1;
        private Label label2;
        private Button savebutton;
    }
}
