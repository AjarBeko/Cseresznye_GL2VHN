﻿using Cseresznye_GL2VHN;
using Cseresznye_GL2VHN.Cherry;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cseresznye_GL2VHN
{

    public partial class UserControl1 : UserControl
    {
        CherryContext context = new CherryContext();
        public UserControl1()
        {
            InitializeComponent();
            context = new CherryContext();
            LoadUgyfelek();
        }
        private void LoadUgyfelek()
        {
            var i = from x in context.Ugyfels
                    where x.Nev.Contains(textBox1.Text) || x.Email.Contains(textBox1.Text)
                    orderby x.Nev
                    select x;
            ugyfelekbindingSource1.DataSource = i.ToList();
            ugyfelekbindingSource1.ResetCurrentItem();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            LoadUgyfelek();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ugyfelekbindingSource1.Current != null)
            {
                var eredmeny = MessageBox.Show("Biztosan törölni szeretnéd az adott rekordot?", "Törlés?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (eredmeny == DialogResult.Yes)
                    
                {
                    var user = (Ugyfel)ugyfelekbindingSource1.Current;
                    context.Ugyfels.Remove(user);
                    try
                    {
                        context.SaveChanges();
                        ugyfelekbindingSource1.RemoveCurrent();
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message);
                    }
                }
            }
            
        }
    }
}
