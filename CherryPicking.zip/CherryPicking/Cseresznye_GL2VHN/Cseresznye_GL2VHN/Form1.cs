namespace Cseresznye_GL2VHN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Biztosan ki szeretn�l l�pni az alkalmaz�sb�l?",
                 "Kil�p�s meger�s�t�se", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void UgyfelListazas_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UserControl1 usc1 = new UserControl1();
            usc1.Dock = DockStyle.Fill;
            panel1.Controls.Add(usc1);
        }

        private void ugyfelszerkeszt_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UserControl2 usc2 = new UserControl2();
            usc2.Dock = DockStyle.Fill;
            panel1.Controls.Add(usc2);
        }


        private void autoklistazasa_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UserControl3 usc3 = new UserControl3();
            usc3.Dock = DockStyle.Fill;
            panel1.Controls.Add(usc3);
        }
    }
}