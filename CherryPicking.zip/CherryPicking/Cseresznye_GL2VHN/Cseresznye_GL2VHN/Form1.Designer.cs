﻿namespace Cseresznye_GL2VHN
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            UgyfelListazas = new Button();
            ugyfelszerkeszt = new Button();
            autoklistazasa = new Button();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.Location = new Point(117, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(678, 441);
            panel1.TabIndex = 0;
            // 
            // UgyfelListazas
            // 
            UgyfelListazas.Location = new Point(12, 5);
            UgyfelListazas.Name = "UgyfelListazas";
            UgyfelListazas.Size = new Size(99, 41);
            UgyfelListazas.TabIndex = 0;
            UgyfelListazas.Text = "Ügyfelek Listázása";
            UgyfelListazas.UseVisualStyleBackColor = true;
            UgyfelListazas.Click += UgyfelListazas_Click;
            // 
            // ugyfelszerkeszt
            // 
            ugyfelszerkeszt.Location = new Point(12, 52);
            ugyfelszerkeszt.Name = "ugyfelszerkeszt";
            ugyfelszerkeszt.Size = new Size(99, 40);
            ugyfelszerkeszt.TabIndex = 1;
            ugyfelszerkeszt.Text = "Ügyfelek szerkesztése";
            ugyfelszerkeszt.UseVisualStyleBackColor = true;
            ugyfelszerkeszt.Click += ugyfelszerkeszt_Click;
            // 
            // autoklistazasa
            // 
            autoklistazasa.Location = new Point(12, 98);
            autoklistazasa.Name = "autoklistazasa";
            autoklistazasa.Size = new Size(99, 42);
            autoklistazasa.TabIndex = 2;
            autoklistazasa.Text = "Gépjárművek";
            autoklistazasa.UseVisualStyleBackColor = true;
            autoklistazasa.Click += autoklistazasa_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Yellow;
            ClientSize = new Size(800, 450);
            Controls.Add(autoklistazasa);
            Controls.Add(ugyfelszerkeszt);
            Controls.Add(UgyfelListazas);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            FormClosing += Form1_FormClosing;
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button UgyfelListazas;
        private Button ugyfelszerkeszt;
        private Button autoklistazasa;
    }
}