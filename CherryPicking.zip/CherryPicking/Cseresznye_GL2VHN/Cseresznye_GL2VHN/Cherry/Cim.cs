﻿using System;
using System.Collections.Generic;

namespace Cseresznye_GL2VHN.Cherry
{
    public partial class Cim
    {
        public int CimId { get; set; }
        public string Utca { get; set; } = null!;
        public string Hazszam { get; set; } = null!;
        public string Varos { get; set; } = null!;
        public string Iranyitoszam { get; set; } = null!;
        public string Orszag { get; set; } = null!;
    }
}
