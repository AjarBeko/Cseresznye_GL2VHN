﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Cseresznye_GL2VHN.Cherry
{
    public partial class CherryContext : DbContext
    {
        public CherryContext()
        {
        }

        public CherryContext(DbContextOptions<CherryContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Auto> Autos { get; set; } = null!;
        public virtual DbSet<Autosbase> Autosbases { get; set; } = null!;
        public virtual DbSet<Cim> Cims { get; set; } = null!;
        public virtual DbSet<Ugyfel> Ugyfels { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=cherrypicking.database.windows.net;Initial Catalog=Cherry;User ID=hallgato;Password=Password123;Trust Server Certificate=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Auto>(entity =>
            {
                entity.ToTable("AUTO");

                entity.Property(e => e.GyartasiEv).HasMaxLength(10);

                entity.Property(e => e.Kivitel).HasMaxLength(50);

                entity.Property(e => e.Marka).HasMaxLength(100);

                entity.Property(e => e.Modell).HasMaxLength(20);

                entity.Property(e => e.Motorcm3).HasMaxLength(10);

                entity.Property(e => e.Szarmazas).HasMaxLength(50);

                entity.Property(e => e.UgyfelId).HasColumnName("UgyfelID");
            });

            modelBuilder.Entity<Autosbase>(entity =>
            {
                entity.HasKey(e => e.AutoId)
                    .HasName("PK__AUTOSBAS__6B23290585F04B43");

                entity.ToTable("AUTOSBASE");

                entity.Property(e => e.GyartasiEv).HasMaxLength(10);

                entity.Property(e => e.Kivitel).HasMaxLength(50);

                entity.Property(e => e.Marka).HasMaxLength(100);

                entity.Property(e => e.Modell).HasMaxLength(20);

                entity.Property(e => e.Motorcm3).HasMaxLength(10);

                entity.Property(e => e.Szarmazas).HasMaxLength(50);
            });

            modelBuilder.Entity<Cim>(entity =>
            {
                entity.ToTable("CIM");

                entity.Property(e => e.CimId).HasColumnName("CimID");

                entity.Property(e => e.Hazszam).HasMaxLength(20);

                entity.Property(e => e.Iranyitoszam).HasMaxLength(10);

                entity.Property(e => e.Orszag).HasMaxLength(50);

                entity.Property(e => e.Utca).HasMaxLength(100);

                entity.Property(e => e.Varos).HasMaxLength(50);
            });

            modelBuilder.Entity<Ugyfel>(entity =>
            {
                entity.ToTable("UGYFEL");

                entity.HasIndex(e => e.Email, "UQ__UGYFEL__A9D105343C370438")
                    .IsUnique();

                entity.Property(e => e.UgyfelId).HasColumnName("UgyfelID");

                entity.Property(e => e.Email).HasMaxLength(255);

                entity.Property(e => e.LakcimId).HasColumnName("LakcimID");

                entity.Property(e => e.Nev).HasMaxLength(100);

                entity.Property(e => e.Telefonszam).HasMaxLength(20);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
