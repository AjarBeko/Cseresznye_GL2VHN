﻿using System;
using System.Collections.Generic;

namespace Cseresznye_GL2VHN.Cherry
{
    public partial class Auto
    {
        public int AutoId { get; set; }
        public string GyartasiEv { get; set; } = null!;
        public string Marka { get; set; } = null!;
        public string Modell { get; set; } = null!;
        public string Kivitel { get; set; } = null!;
        public string Motorcm3 { get; set; } = null!;
        public string Szarmazas { get; set; } = null!;
        public int? UgyfelId { get; set; }
    }
}
