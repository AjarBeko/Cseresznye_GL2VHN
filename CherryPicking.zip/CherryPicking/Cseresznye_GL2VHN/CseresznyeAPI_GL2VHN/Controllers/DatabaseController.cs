﻿using CseresznyeAPI_GL2VHN.Cherry;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CseresznyeAPI_GL2VHN.Controllers
{
    [Route("api/Cars")]
    [ApiController]
    public class CherryCarsController : ControllerBase
    {
        // GET: api/<CherryCarsController>
        [HttpGet("api/autos")]
        public IActionResult GetAllAutos()
        {
            CherryContext context = new CherryContext();
            return Ok(context.Autos.ToList());
        }
        [HttpGet("api/cims")]
        public IActionResult GetAllCims()
        {
            CherryContext context = new CherryContext();
            return Ok(context.Cims.ToList());
        }
        [HttpGet("api/ugyfels")]
        public IActionResult GetAllUgyfels()
        {
            CherryContext context = new CherryContext();
            return Ok(context.Ugyfels.ToList());
        }

        // GET api/<CherryCarsController>/5
        [HttpGet("{id}/autos")]
        public IActionResult GetAutos(int id)
        {
            CherryContext context = new CherryContext();
            var keresett = (from x in context.Autos
                            where x.AutoId == id
                            select x).FirstOrDefault();
            if (keresett == null)
            {
                return NotFound($"Nincs #{id} azonosítóval Auto");
            }
            else
            {
                return Ok(keresett);
            }
        }
        [HttpGet("{id}/cims")]
        public IActionResult GetCims(int id)
        {
            CherryContext context = new CherryContext();
            var keresett = (from x in context.Cims
                            where x.CimId == id
                            select x).FirstOrDefault();
            if (keresett == null)
            {
                return NotFound($"Nincs #{id} azonosítóval Cim");
            }
            else
            {
                return Ok(keresett);
            }
        }
        [HttpGet("{id}/ugyfels")]
        public IActionResult GetUgyfels(int id)
        {
            CherryContext context = new CherryContext();
            var keresett = (from x in context.Ugyfels
                            where x.UgyfelId == id
                            select x).FirstOrDefault();
            if (keresett == null)
            {
                return NotFound($"Nincs #{id} azonosítóval Ügyfél");
            }
            else
            {
                return Ok(keresett);
            }
        }

        // POST api/<CherryCarsController>
        [HttpPost("api/autos")]
        public void PostAutos([FromBody] Auto ujAuto)
        {
            CherryContext context = new CherryContext();
            context.Autos.Add(ujAuto);
            context.SaveChanges();
        }
        [HttpPost("api/cims")]
        public void PostCims([FromBody] Cim ujCim)
        {
            CherryContext context = new CherryContext();
            context.Cims.Add(ujCim);
            context.SaveChanges();
        }
        [HttpPost("api/ugyfels")]
        public void PostUgyfels([FromBody] Ugyfel ujUgyfel)
        {
            CherryContext context = new CherryContext();
            context.Ugyfels.Add(ujUgyfel);
            context.SaveChanges();
        }

        [HttpDelete("{id}/autos")]
        public void DeleteAutos(int id)
        {
            CherryContext context = new CherryContext();
            var torlendo = (from x in context.Autos
                            where x.AutoId == id
                            select x).FirstOrDefault();
            context.Remove(torlendo);
            context.SaveChanges();
        }
        [HttpDelete("{id}/cims")]
        public void DeleteCims(int id)
        {
            CherryContext context = new CherryContext();
            var torlendo = (from x in context.Cims
                            where x.CimId == id
                            select x).FirstOrDefault();
            context.Remove(torlendo);
            context.SaveChanges();
        }
        [HttpDelete("{id}/ugyfels")]
        public void DeleteUgyfels(int id)
        {
            CherryContext context = new CherryContext();
            var torlendo = (from x in context.Ugyfels
                            where x.UgyfelId == id
                            select x).FirstOrDefault();
            context.Remove(torlendo);
            context.SaveChanges();
        }
    }
}
