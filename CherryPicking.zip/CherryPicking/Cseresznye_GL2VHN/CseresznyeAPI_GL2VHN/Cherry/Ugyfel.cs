﻿using System;
using System.Collections.Generic;

namespace CseresznyeAPI_GL2VHN.Cherry
{
    public partial class Ugyfel
    {
        public int UgyfelId { get; set; }
        public string Nev { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? Telefonszam { get; set; }
        public int LakcimId { get; set; }
        public int AutoId { get; set; }
    }
}
